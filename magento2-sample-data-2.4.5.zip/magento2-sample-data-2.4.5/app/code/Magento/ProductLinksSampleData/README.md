Magento_ProductLinksSampleData module consists of installation scripts and fixtures.
